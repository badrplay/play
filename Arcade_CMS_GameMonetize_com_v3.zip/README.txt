###########################################################################
#     GameMonetize.com CMS Installation  - Awesome Free Arcade Script!    #
###########################################################################

Follow this steps to setup GameMonetize.com CMS and in few minutes you will have this games platform running in your server.
Recommended Configuration: PHP 5.6, MySQL
If the installation fails, please delete the file config.php and install-blank.php (located at: /assets/includes/) and start again. :)

STEP 1:
Create a database

STEP 2:
Upload the files inside the "Upload" folder on your FTP or local host, you can install this script in root or subfolder, as you prefer. You only need to set the url to the root or subfolder

STEP 3:
Once you have uploaded all files on your server it is very simple to install it. If you have install GameMonetize.com CMS in root of your server simply open your browser then type in the adress of your chat host ex: http://mydomain.com or if you decided to use a subfolder simply go to ex: http://mydomain.com/subfolder/

STEP 4:
Simply follow these steps and in few minutes you will have a awesome arcade website GameMonetize.com CMS with thousands games for you exclusively for FREE!

STEP 5:
Enjoy GameMonetize.com Arcade CMS - An modern awesome arcade platform for all publishers with thousands games and daily newest games!

Visit us:       https://gamemonetize.com
Join us:        https://gamemonetize.com/joinus
Games Catalog:  https://gamemonetize.com/games

###########################################################################
#              Credits: GameMonetize.com Copyright � 2021                 #
###########################################################################

GameMonetize.com � 2021 GMO Holding Ltd. - All Rights Reserved �

FAQ:
Where I can add a new theme?
In the /templates/ folder make a copy of the /modern/ (template by default) and edit it. Use simple css code and create your own awesome arcade website!

Where I can edit the current theme?
Inside the /templates/YOUR-THEME are all necessary folders to edit the style and structure of the current theme.

THEMES AVAILABLE: (switch into your portal settings)
- modern
- friv
- blue
- girls
- kizi
- red
- friv

NOTE:
PHP version 5.6 is recommended

Contact us:           info@gamemonetize.com
Business inquiries:   katie@gamemonetize.com
Do you need any customization this arcade script? Reach us at: info@gamemonetize.com