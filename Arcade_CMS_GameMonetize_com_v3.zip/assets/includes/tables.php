<?php
/**
* GameMonetize.com - Copyright © 2021
*
*
* @author GameMonetize.com
*
*/
define("SETTING", "gm_setting");
define("GAMES", "gm_games");
define("ACCOUNTS", "gm_account");
define("USERS", "gm_users");
define("MEDIA", "gm_media");
define("LOGS", "gm_userlogs");
define("USER_GAME", "gm_favourites");
define("THEMES", "gm_theme");
define("CATEGORIES", "gm_categories");
define("ADS", "gm_ads");
define("CATALOG", "gm_feed_one");