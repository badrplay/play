<div class="category-section-top" style="text-align:center;font-size:20px;margin-bottom:10px;margin-top:20px;color:white;">
	<span data-href="{{CONFIG_SITE_URL}}/categories"><i class="fa fa-tags"></i> @categories@: <i class="fa fa-chevron-right"></i></span><strong style="color:#fc0">{{CATEGORY_NAME}}</strong>
</div>

<div class="content">
	<div id="content" style="margin-bottom:50px;">
	{{CATEGORY_GAMES_LIST}}

	</div>
</div>

<script>
var cat = "{{CATEGORYID}}";
</script>

{{FOOTER_CONTENT}}