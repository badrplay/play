<div class="gamemonetize-main-headself">
	<i class="fa fa-flag-o"></i>
</div>
<div class="general-box _yt10 _yb10 _0e4">
	<form id="adsArea-form" method="POST">
		<div class="g-d5">

			<div class="r05-t _b-r _5e4">
				<span class="_f12">Ads Game 728x90</span>
				<textarea style="height:110px;" class="b-input scroll-custom" name="ad_728x90">{{ADS_AREA_HEADER}}</textarea>

				<span class="_f12">Ads Game 300x250</span>
				<textarea style="height:110px;" class="b-input scroll-custom" name="ad_300x250">{{ADS_AREA_FOOTER}}</textarea>

				<span class="_f12">Ads Game 600x300</span>
				<textarea style="height:111px;" class="b-input scroll-custom" name="ad_600x300">{{ADS_AREA_COLUMN_ONE}}</textarea>
			</div>
			<div class="r05-t _5e4">
				<span class="_f12">Ads Main 728x90</span>
				<textarea style="height:110px;" class="b-input scroll-custom" name="ad_728x90_main">{{ADS_AREA_GAMETOP}}</textarea>

				<span class="_f12">Ads Main 300x250</span>
				<textarea style="height:110px;" class="b-input scroll-custom" name="ad_300x250_main">{{ADS_AREA_GAMEBOTTOM}}</textarea>

				<span class="_f12">Video ads code (pre-load ads) - Do NOT include &description_url=</span>
				<textarea style="height:111px;" class="b-input scroll-custom" name="ads_video">{{ADS_AREA_GAMEINFO}}</textarea>
			</div>

		</div>
		<div class="_a-r _5e4 _b-t">
			<button type="submit" class="btn-p btn-p1">
				<i class="fa fa-check icon-middle"></i>
				@save@
			</button>
		</div>
	</form>
</div>