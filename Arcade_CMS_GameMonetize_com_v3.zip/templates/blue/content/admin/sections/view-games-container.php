<ul class="_manage--games-list _yt10 _yb10" style="width:100%">
	{{VIEW_GAMES_LIST}}
</ul>

{{VIEW_GAMES_PAGINATION}}