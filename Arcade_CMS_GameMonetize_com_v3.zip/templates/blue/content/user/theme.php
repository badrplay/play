    <form class="theme-form" method="post">
        <ul class="_theme-palette _a-c">
            {{THEME_LIST}}
        </ul>
        <div class="_a-r">
            <button class="btn-p btn-p1">
                <i class="fa fa-check icon-middle"></i>
                @save@
            </button>
        </div>
    </form>