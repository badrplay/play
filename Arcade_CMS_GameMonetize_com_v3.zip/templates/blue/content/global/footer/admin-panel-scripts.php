<script type="text/javascript" src="{{CONFIG_THEME_PATH}}/js/admin/engine-admin.js"></script>
<script type="text/javascript" src="{{CONFIG_THEME_PATH}}/js/libs/owl/owl.carousel.min.js"></script>
<script type="text/javascript" src="{{CONFIG_THEME_PATH}}/js/libs/sweetalert.min.js"></script>
<script type="text/javascript" src="{{CONFIG_THEME_PATH}}/js/libs/bigscreen.min.js"></script>
<script type="text/javascript" src="{{CONFIG_THEME_PATH}}/js/libs/toast.min.js"></script>