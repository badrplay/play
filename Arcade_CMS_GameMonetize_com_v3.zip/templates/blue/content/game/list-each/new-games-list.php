<div class="post">
    <a href="{{NEW_GAME_URL}}">
        <img src="{{NEW_GAME_IMAGE}}" alt="{{NEW_GAME_NAME}}">
        <p class="post-name">{{NEW_GAME_NAME}}</p>
        {{NEW_GAME_FEATURED}}

        {{NEW_GAMES_ICON}}
    </a>
</div>