
             <li>
                    <a href="{{WIDGET_TOPSTAR_URL}}" title="{{WIDGET_TOPSTAR_NAME}}">
                    	 <div class="gameicon" style="background-image: url({{WIDGET_TOPSTAR_IMAGE}});background-size: cover;background-position-x: 50%;background-position-y: 50%;"></div>
                    </a>
                </li>